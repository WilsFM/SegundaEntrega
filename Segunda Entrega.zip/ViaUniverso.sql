CREATE DATABASE ViaUniverso;
USE ViaUniverso;

CREATE TABLE Cliente 
( 
 idCliente INT AUTO_INCREMENT PRIMARY KEY, 
 CPFCliente VARCHAR(15) NOT NULL,  
 telefoneCliente VARCHAR(15) NOT NULL,  
 enderecoCliente VARCHAR(255) NOT NULL,  
 nomeCliente VARCHAR(255) NOT NULL
); 

CREATE TABLE Pacote 
( 
 IdPacote INT AUTO_INCREMENT PRIMARY KEY,  
 naveDeEmbarque VARCHAR(255) NOT NULL,  
 dataDePartida VARCHAR (8),  
 dataDeChegada VARCHAR(8),  
 diasEstadia INT NOT NULL ,  
 quantidadeDeSuporteAvida INT NOT NULL,  
 diasSuspensãoCriogenica INT NOT NULL,  
 idCliente INT NOT NULL  
); 

CREATE TABLE Destino 
( 
 IdDestino INT AUTO_INCREMENT PRIMARY KEY,   
 local VARCHAR(255),  
 tipoDestino ENUM('Lua','Planeta','Asteroide','Espaço'),  
 atividadeDestino ENUM('Trilha','Exploração','Viagem Panoramica', 'Inspeção a base'),  
 idPacote INT NOT NULL
); 

ALTER TABLE Pacote ADD FOREIGN KEY(idCliente) REFERENCES Cliente (idCliente);
ALTER TABLE Destino ADD FOREIGN KEY(idPacote) REFERENCES Pacote (idPacote);