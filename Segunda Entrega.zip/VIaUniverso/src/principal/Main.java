package principal;

import java.util.List;
import java.util.Scanner;

import com.viaUniverso.model.Cliente;
import com.viaUniverso.model.ClienteDAO;
import com.viaUniverso.model.Pacote;

import conector.DatabaseConnection;

public class Main {
	private static Cliente cliente;

	public static void main(String[] args) {
		var connection = DatabaseConnection.createConnection();

		ClienteDAO clienteDAO = new ClienteDAO(connection);
		PacoteDAO pacoteDAO = new PacoteDAO(connection);
		Scanner scanner = new Scanner(System.in);

		int opcao;

		do {
			System.out.println("Menu:");
			System.out.println("1. Criar Cliente");
			System.out.println("2. Listar Clientes");
			System.out.println("3. Atualizar Cliente");
			System.out.println("4. Excluir Cliente");
			System.out.println("5. Criar Pacote");
			System.out.println("6. Listar Pacotes");
			System.out.println("7. Atualizar Pacote");
			System.out.println("8. Excluir Pacote");
			System.out.println("9. Sair");
			System.out.print("Escolha uma opção: ");

			opcao = scanner.nextInt();
			scanner.nextLine(); 

			switch (opcao) {
			case 1:
				criarCliente(scanner, clienteDAO);
				break;
			case 2:
				listarClientes(clienteDAO);
				break;
			case 3:
				atualizarCliente(scanner, clienteDAO);
				break;
			case 4:
				excluirCliente(scanner, clienteDAO);
				break;
			case 5:
				criarPacote(scanner, pacoteDAO);
				break;
			case 6:
				listarPacotes(pacoteDAO);
				break;
			case 7:
				atualizarPacote(scanner, pacoteDAO);
				break;
			case 8:
				excluirPacote(scanner, pacoteDAO);
				break;
			case 9:
				System.out.println("Saindo do programa.");
				break;
			default:
				System.out.println("Opção inválida. Tente novamente.");
				break;
			}
		} while (opcao != 9);

		// Fechar a conexão com o banco de dados
		try {
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Métodos para as ações do menu
	////// Create cliente
	private static void criarCliente(Scanner scanner, ClienteDAO clienteDAO) {
        Cliente cliente = new Cliente();

        System.out.println("Digite o nome do Cliente");
        cliente.setNomeCliente(scanner.nextLine());
        System.out.println("Digite o CPF do Cliente");
        cliente.setCPFCliente(scanner.nextLine());
        System.out.println("Digite o Telefone do Cliente");
        cliente.setTelefoneCliente(scanner.nextLine());
        System.out.println("Digite o Endereço do Cliente");
        cliente.setEnderecoCliente(scanner.nextLine());

        clienteDAO.createClient(cliente);}
        
       
      
       
		
		

        // Read Clientes
     
	private static void criarCliente1(Scanner scanner, ClienteDAO clienteDAO) {
		Cliente cliente = new Cliente();

		System.out.println("Digite o nome do Cliente");
		cliente.setNomeCliente(scanner.nextLine());
		System.out.println("Digite o CPF do Cliente");
		cliente.setCPFCliente(scanner.nextLine());
		System.out.println("Digite o Telefone do Cliente");
		cliente.setTelefoneCliente(scanner.nextLine());
		System.out.println("Digite o Endereço do Cliente");
		cliente.setEnderecoCliente(scanner.nextLine());

		clienteDAO.createClient(cliente);
	}

	private static void listarClientes(ClienteDAO clienteDAO) {
		System.out.println("Lista de Clientes:");
		clienteDAO.ReadClients();
	}

	private static void atualizarCliente(Scanner scanner, ClienteDAO clienteDAO) {
		System.out.println("Digite o ID do Cliente que você deseja atualizar:");
		int idCliente = scanner.nextInt();
		scanner.nextLine(); // Consumir a nova linha

		Cliente cliente = new Cliente();
		cliente.setIdCliente(idCliente);

		System.out.println("Digite o novo nome do Cliente:");
		cliente.setNomeCliente(scanner.nextLine());
		System.out.println("Digite o novo CPF do Cliente:");
		cliente.setCPFCliente(scanner.nextLine());
		System.out.println("Digite o novo telefone do Cliente:");
		cliente.setTelefoneCliente(scanner.nextLine());
		System.out.println("Digite o novo endereço do Cliente:");
		cliente.setEnderecoCliente(scanner.nextLine());

		clienteDAO.updateClient(cliente);
	}

	private static void excluirCliente(Scanner scanner, ClienteDAO clienteDAO) {
		System.out.println("Digite o ID do Cliente que você deseja excluir:");
		int idCliente = scanner.nextInt();
		clienteDAO.deleteClient(idCliente);}

		//////////////////// // Pacotes
		// Criar um novo pacote
		private static void criarPacote(Scanner scanner, PacoteDAO pacoteDAO) {
		Pacote novoPacote = new Pacote(0, "Nave123", "2023-10-16", 7, 3, 100);
		pacoteDAO.createPacote(novoPacote);
		}
		private static void listarPacotes(PacoteDAO pacoteDAO) {	
		// Ler todos os pacotes do banco de dados
		List<Pacote> pacotes = pacoteDAO.readPacotes();
		System.out.println("Lista de Pacotes:");
		for (Pacote pacote : pacotes) {
			System.out.println("ID: " + pacote.getIdPacote());
			System.out.println("Nave de Embarque: " + pacote.getNaveDeEmbarque());
			System.out.println("Data de Partida: " + pacote.getDataDePartida());
			System.out.println("Dias de Estadia: " + pacote.getDiasEstadia());
			System.out.println("Quantidade de Suporte à Vida: " + pacote.getQuantidadeDeSuporteAvida());
			System.out.println("Dias de Suspensão Criogênica: " + pacote.getDiasSuspensãoCriogenica());
			System.out.println();}
		}
		private static void atualizarPacote(Scanner scanner, PacoteDAO pacoteDAO) {
		// Atualizar um pacote
		Pacote pacoteAtualizado = new Pacote(1, "Nave456", "2023-10-17", 10, 5, 120);
		pacoteDAO.updatePacote(pacoteAtualizado);}
		private static void excluirPacote(Scanner scanner, PacoteDAO pacoteDAO) {
		// Excluir um pacote
		System.out.println("Digite o ID do Pacote que você deseja excluir:");
		int idPacoteParaExcluir = scanner.nextInt();
		pacoteDAO.deletePacote(idPacoteParaExcluir);

		// Fechar a conexão com o banco de dados
		try {
			Scanner connection = null;
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}