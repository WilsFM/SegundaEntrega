package principal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.viaUniverso.model.Destino;

public class DestinoDAO {
    private static String sql;
    private final Connection connection;

    public DestinoDAO(Connection connection) {
        this.connection = connection;
    }

    // Criar um novo destino
    public void createDestino(Destino destino) {
        sql = "INSERT INTO Destino (local, tipoDestino, atividadeDestino) VALUES (?,?,?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, destino.getLocal());
            stmt.setString(2, destino.getTipoDestino());
            stmt.setString(3, destino.getAtividadeDestino());

            stmt.executeUpdate();
            System.out.println("Destino criado com sucesso.");
        } catch (SQLException e) {
            System.out.println("Não foi possível criar o destino. Mensagem: " + e.getMessage());
        }
    }

    public List<Destino> readDestinos() {
        List<Destino> destinos = new ArrayList<>();
        sql = "SELECT * FROM Destino";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Destino destino = new Destino();
                destino.setIdDestino(rs.getInt("IdDestino")); 
                destino.setLocal(rs.getString("local"));
                destino.setTipoDestino(rs.getString("tipoDestino"));
                destino.setAtividadeDestino(rs.getString("atividadeDestino"));

                destinos.add(destino);
            }
        } catch (SQLException e) {
            System.out.println("Não foi possível obter os dados dos destinos. Mensagem: " + e.getMessage());
        }
		return destinos;}

    // Atualizar um destino
    public void updateDestino(Destino destino) {
        sql = "UPDATE Destino SET local = ?, tipoDestino = ?, atividadeDestino = ? WHERE IdDestino = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, destino.getLocal());
            stmt.setString(2, destino.getTipoDestino());
            stmt.setString(3, destino.getAtividadeDestino());
            stmt.setInt(4, destino.getIdDestino());

            stmt.executeUpdate();
            System.out.println("Destino atualizado com sucesso.");
        } catch (SQLException e) {
            System.out.println("Não foi possível atualizar o destino. Mensagem: " + e.getMessage());
        }
    }

    // Excluir um destino
    public void deleteDestino(int idDestino) {
        sql = "DELETE FROM Destino WHERE IdDestino = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idDestino);

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Destino com ID " + idDestino + " foi excluído com sucesso.");
            } else {
                System.out.println("Nenhum destino foi excluído. Verifique o ID do destino.");
            }
        } catch (SQLException e) {
            System.out.println("Não foi possível excluir o destino. Mensagem: " + e.getMessage());
        }
    }
}

