package principal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.viaUniverso.model.Pacote;

public class PacoteDAO {
	 private static String sql;
	    private final Connection connection;

	    public PacoteDAO(Connection connection) {
	        this.connection = connection;
	    }
///Create Pacote
	    public void createPacote(Pacote pacote) {
	        sql = "INSERT INTO Pacote (naveDeEmbarque, dataDePartida, diasEstadia, quantidadeDeSuporteAvida, diasSuspensãoCriogenica) VALUES (?,?,?,?,?)";
	        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	            stmt.setString(1, pacote.getNaveDeEmbarque());
	            stmt.setString(2, pacote.getDataDePartida());
	            stmt.setInt(3, pacote.getDiasEstadia());
	            stmt.setInt(4, pacote.getQuantidadeDeSuporteAvida());
	            stmt.setInt(5, pacote.getDiasSuspensãoCriogenica());

	            stmt.executeUpdate();
	            System.out.println("Pacote criado com sucesso.");
	        } catch (SQLException e) {
	            System.out.println("Não foi possível criar o pacote. Mensagem: " + e.getMessage());
	        }
	    }
	  ///read Pacote
	    public List<Pacote> readPacotes() {
	        List<Pacote> pacotes = new ArrayList<>();
	        sql = "SELECT * FROM Pacote";
	        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	            ResultSet rs = stmt.executeQuery();

	            while (rs.next()) {
	                Pacote pacote = new Pacote();
	                pacote.setIdPacote(rs.getInt("IdPacote"));
	                pacote.setNaveDeEmbarque(rs.getString("naveDeEmbarque"));
	                pacote.setDataDePartida(rs.getString("dataDePartida"));
	                pacote.setDiasEstadia(rs.getInt("diasEstadia"));
	                pacote.setQuantidadeDeSuporteAvida(rs.getInt("quantidadeDeSuporteAvida"));
	                pacote.setDiasSuspensãoCriogenica(rs.getInt("diasSuspensãoCriogenica"));

	                pacotes.add(pacote);
	            }
	        } catch (SQLException e) {
	            System.out.println("Não foi possível dados dos pacotes. Mensagem: " + e.getMessage());
	        }

	        return pacotes;
	    }
	  ///update Pacote
	    public void updatePacote(Pacote pacote) {
	        sql = "UPDATE Pacote SET naveDeEmbarque = ?, dataDePartida = ?, diasEstadia = ?, quantidadeDeSuporteAvida = ?, diasSuspensãoCriogenica = ? WHERE IdPacote = ?";
	        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	            stmt.setString(1, pacote.getNaveDeEmbarque());
	            stmt.setString(2, pacote.getDataDePartida());
	            stmt.setInt(3, pacote.getDiasEstadia());
	            stmt.setInt(4, pacote.getQuantidadeDeSuporteAvida());
	            stmt.setInt(5, pacote.getDiasSuspensãoCriogenica());
	            stmt.setInt(6, pacote.getIdPacote());

	            stmt.executeUpdate();
	            System.out.println("Pacote atualizado com sucesso.");
	        } catch (SQLException e) {
	            System.out.println("Não foi possível atualizar o pacote. Mensagem: " + e.getMessage());
	        }
	    }
	  ///Delete Pacote
	    
	    public void deletePacote(int idPacote) {
	        sql = "DELETE FROM Pacote WHERE IdPacote = ?";
	        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	            stmt.setInt(1, idPacote);

	            int rowsAffected = stmt.executeUpdate();

	            if (rowsAffected > 0) {
	                System.out.println("Pacote com ID " + idPacote + " foi excluído com sucesso.");
	            } else {
	                System.out.println("Nenhum pacote foi excluído. Verifique o ID do pacote.");
	            }
	        } catch (SQLException e) {
	            System.out.println("Não foi possível excluir o pacote. Mensagem: " + e.getMessage());
	        }
	    }
	}

	
