package com.viaUniverso.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import principal.DestinoDAO;

public class ClienteDAO {

	private static String sql;

	private final Connection connection;
	
	public ClienteDAO(Connection connection) {
		this.connection = connection;
	}
	
	public void createClient(Cliente cliente) {
		sql = "INSERT INTO cliente (CPFCliente, telefoneCliente, enderecoCliente, nomeCliente) VALUES (?,?,?,?)";
		try (PreparedStatement stmt = connection.prepareStatement(sql)) {
			
			stmt.setString(1, cliente.getCPFCliente());
			stmt.setString(2, cliente.getTelefoneCliente());
			stmt.setString(3, cliente.getEnderecoCliente());
			stmt.setString(4, cliente.getNomeCliente());

			stmt.executeUpdate();
			System.out.println( "Cliente criado com sucesso  Nome: "
					+ cliente.getNomeCliente() +
					"\n CPF: " + cliente.getCPFCliente() + 
					"\n Telefone Cliente "+ cliente.getTelefoneCliente() +
					"\n Endereço Cliente " + cliente.getEnderecoCliente());
			
		} catch (SQLException e) {
			System.out.println( "Nao foi possivel criar o cliente." + "Mensagem: " + e.getMessage());

		}
	
	}
	
	
	// READ
		public void ReadClients() {
			sql = "SELECT * FROM Cliente";
			try (PreparedStatement stmt = connection.prepareStatement(sql)) {
				ResultSet r = stmt.executeQuery();
				while (r.next()) {
					Cliente cliente = new Cliente();
					cliente.setCPFCliente(r.getString("CPFCliente"));
					cliente.setNomeCliente(r.getString("nomeCliente"));
					cliente.setIdCliente(r.getInt("idCliente"));
					cliente.setEnderecoCliente(r.getString("enderecoCliente"));
					cliente.setTelefoneCliente(r.getString("telefoneCliente"));

					System.out.printf("ID: %d\n Nome: %s\n CPF: %s\n Endereco: %s\n Telefone: %s\n", cliente.getIdCliente(),
							cliente.getNomeCliente(), cliente.getCPFCliente(), cliente.getEnderecoCliente(),
							cliente.getTelefoneCliente());

				}
				if (!r.next()) {
					System.out.println("Não ha registros");
				}

			} catch (SQLException e) {
				System.out.println( " Nao foi possivel acessar as informacoes." 
						+ "Mensagem: " + e.getMessage());
			}
		}

		// UPDATE
		public void updateClient(Cliente cliente) {
			sql = "UPDATE Cliente SET nomeCliente = ?, CPFCliente = ?, enderecoCliente = ?, telefoneCliente = ? WHERE idCliente = ?";
			try (PreparedStatement stmt = connection.prepareStatement(sql)) {
				stmt.setString(1, cliente.getNomeCliente());
				stmt.setString(2, cliente.getCPFCliente());
				stmt.setString(3, cliente.getEnderecoCliente());
				stmt.setString(4, cliente.getTelefoneCliente());
				stmt.setInt(5, cliente.getIdCliente());

				stmt.executeUpdate();
				System.out.println("Cliente atualizado com sucesso\n"
				+  "Nome: " + cliente.getNomeCliente() + "\nCPF: " + cliente.getCPFCliente());

			} catch (SQLException e) {
				System.out.println("Nao foi possivel atualizar o cliente." + "Mensagem: " + e.getMessage());
			}}
	

			 // DELETE
		    public void deleteClient(int idCliente) {
		        sql = "DELETE FROM Cliente WHERE idCliente = ?";
		        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
		            stmt.setInt(1, idCliente);

		            int rowsAffected = stmt.executeUpdate();

		            if (rowsAffected > 0) {
		                System.out.println("Cliente com ID " + idCliente + " foi excluído com sucesso.");
		            } else {
		                System.out.println("Nenhum cliente foi excluído. Verifique o ID do cliente.");
		            }
		        } catch (SQLException e) {
		            System.out.println("Não foi possível excluir o cliente. Mensagem: " + e.getMessage());
	
	
	
		            DestinoDAO destinoDAO = new DestinoDAO(connection);

		            // Create Destino
		            Destino destino = new Destino();
		            System.out.println("Digite o local do Destino:");
		            
					Scanner scanner = null;
					destino.setLocal(scanner.nextLine());
		            System.out.println("Digite o tipo do Destino:");
		            destino.setTipoDestino(scanner.nextLine());
		            System.out.println("Digite a atividade do Destino:");
		            destino.setAtividadeDestino(scanner.nextLine());

		            destinoDAO.createDestino(destino);

		            // Read Destinos
		            List<Destino> destinos = destinoDAO.readDestinos();
		            System.out.println("Lista de Destinos:");
		            for (Destino d : destinos) {
		                System.out.println("ID: " + d.getIdDestino());
		                System.out.println("Local: " + d.getLocal());
		                System.out.println("Tipo: " + d.getTipoDestino());
		                System.out.println("Atividade: " + d.getAtividadeDestino());
		                System.out.println();
		            }

		            // Atualização de um destino
		            System.out.println("Digite o ID do Destino que você deseja atualizar:");
		            int idDestino = scanner.nextInt();

		            Destino destinoAtualizado = new Destino();
		            destinoAtualizado.setIdDestino(idDestino);
		            System.out.println("Digite o novo local do Destino:");
		            scanner.nextLine(); 
		            destinoAtualizado.setLocal(scanner.nextLine());
		            System.out.println("Digite o novo tipo do Destino:");
		            destinoAtualizado.setTipoDestino(scanner.nextLine());
		            System.out.println("Digite a nova atividade do Destino:");
		            destinoAtualizado.setAtividadeDestino(scanner.nextLine());

		            destinoDAO.updateDestino(destinoAtualizado);

		            // DELETE
		            System.out.println("Digite o ID do Destino que você deseja excluir:");
		            int idDestinoParaExcluir = scanner.nextInt();
		            destinoDAO.deleteDestino(idDestinoParaExcluir);

		          
		            }
		        }
		    }
	
	
	


