package com.viaUniverso.model;

public class Destino {

	private int IdDestino;

	private String local;
	private String tipoDestino;
	private String atividadeDestino;

	public void setIdDestino(int idDestino) {
		IdDestino = idDestino;
	}

	public int getIdDestino() {
		return IdDestino;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	public String getTipoDestino() {
		return tipoDestino;
	}

	public void setTipoDestino(String tipoDestino) {
		this.tipoDestino = tipoDestino;
	}

	public String getAtividadeDestino() {
		return atividadeDestino;
	}

	public void setAtividadeDestino(String atividadeDestino) {
		this.atividadeDestino = atividadeDestino;
	}

}
