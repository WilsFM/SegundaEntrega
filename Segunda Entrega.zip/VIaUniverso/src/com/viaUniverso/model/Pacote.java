package com.viaUniverso.model;

public class Pacote {

	private int IdPacote;
	private String naveDeEmbarque;
	private String dataDePartida;
	private int diasEstadia;
	private int quantidadeDeSuporteAvida;
	private int diasSuspensãoCriogenica;

	public Pacote(int IdPacote, String naveDeEmbarque, String dataDePartida, int diasEstadia,
			int quantidadeDeSuporteAvida, int diasSuspensãoCriogenica) {
		super();
		this.IdPacote = IdPacote;
		this.naveDeEmbarque = naveDeEmbarque;
		this.dataDePartida = dataDePartida;
		this.diasEstadia = diasEstadia;
		this.quantidadeDeSuporteAvida = quantidadeDeSuporteAvida;
		this.diasSuspensãoCriogenica = diasSuspensãoCriogenica;
	}

	public Pacote() {
		super();
	}

	public void setIdPacote(int idPacote) {
		IdPacote = idPacote;
	}

	public String getNaveDeEmbarque() {
		return naveDeEmbarque;
	}

	public void setNaveDeEmbarque(String naveDeEmbarque) {
		this.naveDeEmbarque = naveDeEmbarque;
	}

	public String getDataDePartida() {
		return dataDePartida;
	}

	public void setDataDePartida(String dataDePartida) {
		this.dataDePartida = dataDePartida;
	}

	public int getDiasEstadia() {
		return diasEstadia;
	}

	public void setDiasEstadia(int diasEstadia) {
		this.diasEstadia = diasEstadia;
	}

	public int getQuantidadeDeSuporteAvida() {
		return quantidadeDeSuporteAvida;
	}

	public void setQuantidadeDeSuporteAvida(int quantidadeDeSuporteAvida) {
		this.quantidadeDeSuporteAvida = quantidadeDeSuporteAvida;
	}

	public int getDiasSuspensãoCriogenica() {
		return diasSuspensãoCriogenica;
	}

	public void setDiasSuspensãoCriogenica(int diasSuspensãoCriogenica) {
		this.diasSuspensãoCriogenica = diasSuspensãoCriogenica;
	}

	public int getIdPacote() {
		return IdPacote;
	}

}
