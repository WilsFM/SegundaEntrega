package com.viaUniverso.model;

public class Cliente {

	private String CPFCliente;
	private String telefoneCliente;
	private String enderecoCliente;
	private String nomeCliente;
	private int idCliente;

	public Cliente() {
		super();
	}

	public Cliente(String CPFCliente, String telefoneCliente, String enderecoCliente, String nomeCliente,
			int idCliente) {
		super();
		this.CPFCliente = CPFCliente;
		this.telefoneCliente = telefoneCliente;
		this.enderecoCliente = enderecoCliente;
		this.nomeCliente = nomeCliente;
		this.idCliente = idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public int getIdCliente() {
		return idCliente;
	}

	public String getCPFCliente() {
		return CPFCliente;
	}

	public void setCPFCliente(String cPFCliente) {
		CPFCliente = cPFCliente;
	}

	public String getTelefoneCliente() {
		return telefoneCliente;
	}

	public void setTelefoneCliente(String telefoneCliente) {
		this.telefoneCliente = telefoneCliente;
	}

	public String getEnderecoCliente() {
		return enderecoCliente;
	}

	public void setEnderecoCliente(String enderecoCliente) {
		this.enderecoCliente = enderecoCliente;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public void setNomeCliente(String nomeCliente) {
		this.nomeCliente = nomeCliente;
	}

}
