package conector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	private static final String url = "jdbc:mysql://localhost:3306/ViaUniverso";

	private static final String user = "root";

	private static final String password = "root";

	public static Connection createConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Drive encontrado");
		} catch (ClassNotFoundException e) {
			System.out.println("Drive não encontrado Mensagem:  " + e);
		}
		;

		try {
			Connection connection = DriverManager.getConnection(url, user, password);
			System.out.println("Conectado com sucesso!");

			return connection;
		} catch (SQLException e) {
			System.out.printf(" Não foi possivel conectar Mensagem: " + e);
			return null;
		}

	}

}
