/**
 * 
 */
/**
 * 
 */
module VIaUniverso {
	requires java.sql;
}